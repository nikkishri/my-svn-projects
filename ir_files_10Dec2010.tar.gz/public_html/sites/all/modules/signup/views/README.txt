$Id: README.txt,v 1.1 2008/11/01 01:39:16 dww Exp $

This directory contains the files necessary to provide integration
between the Signup module and the Views module.  For more information
about Views, see the project page: http://drupal.org/project/views.
