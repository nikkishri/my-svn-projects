/*
 * progressbar_options.js
 */
(function($) {

module("progressbar: options");

test("{ value : 0 }, default", function() {
	ok(false, "missing test - untested code is broken code.");
});

})(jQuery);
